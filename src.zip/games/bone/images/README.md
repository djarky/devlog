Add your web app cover here named as `128.png`
or edit the `icon` path in `manifest.webapp` to point to your image.
